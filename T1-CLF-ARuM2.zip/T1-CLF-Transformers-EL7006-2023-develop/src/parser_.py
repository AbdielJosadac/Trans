
import pickle
import glob
import argparse


def parse_model_args(arg_dict=None):
    """Parse command line arguments """
    parser = argparse.ArgumentParser()
    # embedding
    parser.add_argument("--num_bands", type=int, default=2)
    parser.add_argument("--embedding_size", type=int, default=512)
    parser.add_argument("--embedding_size_sub", type=int, default=2048)
    parser.add_argument("--num_heads", type=int, default=4)
    parser.add_argument("--num_encoders", type=int, default=2)
    parser.add_argument("--Tmax", type=float, default=1500.0)
    parser.add_argument("--num_harmonics", type=int, default=16)
    parser.add_argument("--num_classes", type=int, default=5)

    args = parser.parse_args(None if arg_dict is None else [])
    required_args = ['Tmax']

    for key in required_args:
        if getattr(args, key) is None:
            parser.error("Missing argument {}".format(key))

    return args
