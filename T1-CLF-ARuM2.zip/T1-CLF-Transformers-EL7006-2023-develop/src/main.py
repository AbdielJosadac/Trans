
import torch
from parser_ import parse_model_args
from layers import Template

if __name__ == '__main__':

    args = vars(parse_model_args(arg_dict=None))
    model = Template(**args)

    print(args)
    print(model)

    n_batch = 64
    n_seq = 40

    # input dimension, data : n_batch, seq_lengh, num_chanels
    # input dimension, time : n_batch, seq_lengh, num_chanels
    # input dimension, mask : n_batch, seq_lengh, num_chanels

    input_sample = {
        'data': torch.rand(n_batch, n_seq, 2),
        'time': torch.rand(n_batch, n_seq, 2),
        'mask': torch.ones(n_batch, n_seq, 2)
    }

    d
    output_sample = model(**input_sample)

    print('n_batch , num_classes :', output_sample.shape)
