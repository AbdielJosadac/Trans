import torch
import torch.nn as nn

from .timeEncoders import TimeHandler
from .transformer import Transformer
from .classifiers import TokenClassifier
from .tokenEmbeddings import Token


class Template(nn.Module):
    def __init__(self,  **kwargs):
        super(Template, self).__init__()

        # Time encoders
        self.time_encoder = TimeHandler(**kwargs)
        # Transformers
        self.transformer_lc = Transformer(**kwargs)
        # Token
        self.token_lc = Token(**kwargs)
        # Classifiers
        self.classifier_lc = TokenClassifier(**kwargs)
        # init model params
        self.init_model()

    def init_model(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.normal_(p, 0, 0.02)

    def embedding_light_curve(self, x, t, mask=None, **kwargs):

        batch_size = x.shape[0]
        m_token = torch.ones(batch_size, 1, 1).float().to(x.device)
        # Modulation
        x_mod, m_mod, t_mod = self.time_encoder(
            **{'x': x, 't': t, 'mask': mask})
        x_mod = torch.cat([self.token_lc(batch_size), x_mod], axis=1)
        m_mod = torch.cat([m_token, m_mod], axis=1)

        return x_mod, m_mod, t_mod

    def forward(self, data, time, mask=None,  **kwargs):

        # Light curve prediction
        x_mod, m_mod, _ = self.embedding_light_curve(
            **{'x': data, 't': time, 'mask': mask})
        x_emb = self.transformer_lc(**{'x': x_mod, 'mask': m_mod})
        x_cls = self.classifier_lc(x_emb[:, 0, :])

        return x_cls
