# Transformers-EL7006

En este repositorio se entrega un modelo de Transformer el cual puede ser modificado a gusto, en la carpeta ./layers se encuentran todos los modulos necesarios para la construccion del modelo Template declarado en ./layers/Template.py

Para construir el modelo de ejemplo es solo necesario ejecutar la siguiente linea a la altura de .src/

`$ python3 main.py`

Notar que se ha integrado un parseador de argumentos, por lo que si se busca modificar algun hiperparamtro del modelo, como la dimension de los embedding o numero de cabezas , simplemente se pueden ir agregando flags. Por ejemplo si se busca que existan 4 encoders consecutivos el comando seria:

`$ python3 main.py --num_encoders 4`

En caso que se quieran modelos de mayor dimensionalidad y numero de cabezas de atencion

`$ python3 main.py --num_encoders 2 --embedding_size 1024 --num_heads 32`

## Consideraciones para uso del repositorio

Para evitar que en futuras entregas del curso existan conflictos entre el codigo de ejemplo y las modificaciones que se vayan a realizar sobre este, se pide que para guardar cambios estos vayan a una rama de desarrollo, en otras palabras al clonar este repositorio deberan crear una nueva rama y pushear sus cambios a esta.
