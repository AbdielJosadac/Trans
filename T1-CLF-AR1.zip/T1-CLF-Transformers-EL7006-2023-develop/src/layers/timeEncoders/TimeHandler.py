import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from .TimeFilm import TimeFilm
from ..utils import clones


class TimeHandler(nn.Module):

    def __init__(self, num_bands=2, embedding_size=64, Tmax=1500.0, **kwargs):
        super(TimeHandler, self).__init__()
        # general params
        self.num_bands = num_bands
        self.ebedding_size = embedding_size
        self.T_max = Tmax
        # tume_encoders
        self.time_encoders = clones(
            TimeFilm(embedding_size=embedding_size, Tmax=Tmax), num_bands)

    def forward(self, x, t, mask, **kwargs):

        x_mod = []
        t_mod = []
        m_mod = []
        for i in range(self.num_bands):

            x_mod.append(self.time_encoders[i](x[:, :, i:i+1], t[:, :, i:i+1]))
            t_mod.append(t[:, :, i:i+1])
            m_mod.append(mask[:, :, i:i+1])

        x_mod = torch.cat(x_mod, axis=1)
        t_mod = torch.cat(t_mod, axis=1)
        m_mod = torch.cat(m_mod, axis=1)

        return x_mod, m_mod, t_mod
